var create_Element;
var outOfOffice_Element;
var container_Element;
var checkbox_content
var checkbox_div;
var mail_Content;
var saveButton;
var tokenData;
var token;
var startTimeValue;
var endTimeValue;
var startTime;
var endTime;
var eventList;
var mail_Content_Value;

 

 

async function initCreateTemplate() {
    var location = window.location.href;
    var url = "https://calendar.google.com/calendar/";
    if (location.includes(url)) {
      create_Element = document.querySelector('.lUmaj.buGMKc');
      create_Element.addEventListener('click', async function () {
      outOfOffice_Element = await document.querySelector('span[aria-label="Out of office"]');
      if (outOfOffice_Element) {
          if (!outOfOffice_Element.hasEventListener) {
            outOfOffice_Element.hasEventListener = true;
            outOfOffice_Element.addEventListener('click', async function () {
              container_Element = await document.querySelector('div[jsname="xlVhlb"]');
              if (!container_Element) {
                await new Promise((resolve) => setTimeout(resolve, 1000));
                container_Element = await document.querySelector('div[jsname="xlVhlb"]');

                checkbox_div = document.createElement("input");
                checkbox_div.className = "checkbox";
                checkbox_div.type = "checkbox";
                container_Element.appendChild(checkbox_div);

                checkbox_content = document.createElement("div");
                checkbox_content.className = "checkboxContent";
                checkbox_content.textContent = "Automatically send mail";
                container_Element.appendChild(checkbox_content);

                mail_Content = document.createElement("input");
                mail_Content.className = "mailContent";
                mail_Content.placeholder="Enter mail content here"
                mail_Content.type= "text";
                checkbox_content.appendChild(mail_Content);

                if (mail_Content) {
                    if (mail_Content.value.trim().length > 0) {
                        mail_Content.classList.add('showBorder');
                      } else {
                        mail_Content.classList.remove('showBorder');
                      }
                }

                saveButton = document.querySelector('button[jsname="x8hlje"]');
                saveButton.addEventListener('click',async function(){
                  if(checkbox_div.checked == true){
                    startTimeValue = document.querySelector('span[data-key="startDate"]').innerHTML;
                    endTimeValue = document.querySelector('span[data-key="endDate"]').innerHTML;
                    var startTimeString = new Date(startTimeValue);
                    var endTimeString = new Date(endTimeValue);
                    console.log(startTimeString)
                    console.log(endTimeString)
                    mail_Content_Value = mail_Content.value;
                  }

                });

              }
      });

      }

      }

      });
    }
  }

 

  const mainFunction = async () => {
    window.addEventListener('load', async function () {
      await initCreateTemplate();
    });
  }

  mainFunction();

 

